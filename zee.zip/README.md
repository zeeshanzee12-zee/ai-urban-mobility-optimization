# AI-Driven Urban Mobility Optimization

An interactive simulation that compares **fixed-timer traffic signals** with an **AI adaptive signal controller** on a 3×3 smart-city grid. Both grids receive exactly the same traffic, so the difference in results comes only from the signal control.

## Features
- Side-by-side simulation of fixed-timer and AI adaptive signals
- Adjustable demand (cars per minute) and a rush-hour surge on the east–west roads
- Live metrics: average delay per car, throughput, stopped cars, vehicles waiting to enter
- Delay-over-time chart for both controllers
- Runs in the browser with no installation or libraries

## How it works
- **Data:** vehicle counts and queue lengths are simulated. In a real deployment they would come from road sensors, cameras or GPS probe data.
- **Fixed-timer:** each junction alternates green every 10 seconds on its own uncoordinated timer.
- **AI adaptive controller:** each junction scores both directions using stopped cars, approaching cars, cars waiting to enter and how long the other direction has waited. It switches when the other direction has clearly more demand (minimum green 5 s, maximum 30 s).
- **Delay** is the extra travel time compared with an empty road.

This controller is a rule-based predictive model, not a trained neural network.

## Run it
Open `index.html` in any modern browser.

## Future work
- Replace the scoring rule with a reinforcement-learning agent
- Add a forecasting model for vehicle arrivals
- Connect to real traffic data (sensors or open traffic APIs)
- Add turning movements, pedestrians and emergency-vehicle priority

## Tech
HTML, CSS and JavaScript (Canvas).
